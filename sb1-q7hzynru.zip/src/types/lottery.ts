export interface LotteryDraw {
  id: number;
  type: 'kadoo' | 'matinal' | 'super' | 'million' | 'prestige' | 'benz';
  drawNumber: number;
  date: string;
  numbers: number[];
  url: string;
  isWinning?: boolean;
}

export interface LotteryType {
  name: string;
  displayName: string;
  color: string;
  icon: string;
}

export interface AnalysisResult {
  dominantNumbers: number[];
  luckyNumbers: number[];
  numerologySum: number;
  prediction: number[];
  confidence: number;
  patternAnalysis: {
    evenOddRatio: number;
    highLowRatio: number;
    consecutiveNumbers: number;
  };
}

export interface StatsData {
  totalDraws: number;
  successRate: number;
  averageNumbers: number[];
  mostFrequent: number[];
  recentTrend: 'up' | 'down' | 'stable';
  byLotteryType: Record<string, {
    count: number;
    lastDraw: string;
    avgNumbers: number[];
  }>;
}