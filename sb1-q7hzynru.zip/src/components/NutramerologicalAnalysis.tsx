import React from 'react';
import { Brain, Calculator, Zap, TrendingUp } from 'lucide-react';
import { AnalysisResult } from '../types/lottery';

interface NutramerologicalAnalysisProps {
  analysis: AnalysisResult;
  isCalculating: boolean;
}

export function NutramerologicalAnalysis({ analysis, isCalculating }: NutramerologicalAnalysisProps) {
  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-100 rounded-2xl shadow-xl p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Brain className="h-6 w-6 text-purple-600" />
        <h2 className="text-2xl font-bold text-gray-800">Analyse Numérologique Avancée</h2>
      </div>

      {isCalculating ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
          <span className="ml-4 text-purple-600 font-medium">Calcul des patterns numérologiques...</span>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-4 shadow-md">
                <h3 className="font-semibold text-gray-700 mb-3 flex items-center">
                  <Calculator className="h-4 w-4 mr-2" />
                  Chiffres Dominants
                </h3>
                <div className="flex space-x-2">
                  {analysis.dominantNumbers.map((num, index) => (
                    <div key={index} className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                      {num}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl p-4 shadow-md">
                <h3 className="font-semibold text-gray-700 mb-3">Somme Numérologique</h3>
                <div className="text-2xl font-bold text-purple-600">{analysis.numerologySum}</div>
              </div>

              <div className="bg-white rounded-xl p-4 shadow-md">
                <h3 className="font-semibold text-gray-700 mb-3">Niveau de Confiance</h3>
                <div className="flex items-center">
                  <div className="flex-1 bg-gray-200 rounded-full h-3 mr-3">
                    <div 
                      className="bg-gradient-to-r from-green-400 to-blue-500 h-3 rounded-full transition-all duration-500"
                      style={{ width: `${analysis.confidence}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium text-gray-600">{analysis.confidence}%</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-white rounded-xl p-4 shadow-md">
                <h3 className="font-semibold text-gray-700 mb-3 flex items-center">
                  <Zap className="h-4 w-4 mr-2" />
                  Chiffres Porte-Bonheur
                </h3>
                <div className="flex space-x-2">
                  {analysis.luckyNumbers.map((num, index) => (
                    <div key={index} className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                      {num}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl p-4 shadow-md">
                <h3 className="font-semibold text-gray-700 mb-3 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Analyse des Patterns
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Ratio Pair/Impair:</span>
                    <span className="font-medium">{Math.round(analysis.patternAnalysis.evenOddRatio * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Ratio Haut/Bas:</span>
                    <span className="font-medium">{Math.round(analysis.patternAnalysis.highLowRatio * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Nombres Consécutifs:</span>
                    <span className="font-medium">{analysis.patternAnalysis.consecutiveNumbers}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl p-6 text-white shadow-lg">
            <h3 className="font-bold text-lg mb-4 flex items-center">
              <Sparkles className="h-5 w-5 mr-2" />
              Prédiction Prochaine (Basée sur Lonato Togo)
            </h3>
            <div className="flex space-x-3 justify-center">
              {analysis.prediction.map((number, index) => (
                <div
                  key={index}
                  className="w-12 h-12 bg-white bg-opacity-20 backdrop-blur-sm rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg border-2 border-white border-opacity-30"
                >
                  {number}
                </div>
              ))}
            </div>
            <p className="text-center mt-4 text-sm opacity-90">
              Prédiction générée automatiquement après analyse des derniers tirages
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Sparkles({ className }: { className?: string }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 20 20">
      <path d="M5 4a1 1 0 00-2 0v1.5H1.5a1 1 0 000 2H3V9a1 1 0 002 0V7.5h1.5a1 1 0 000-2H5V4zM14 7a1 1 0 10-2 0v1.5h-1.5a1 1 0 100 2H12V12a1 1 0 102 0v-1.5h1.5a1 1 0 100-2H14V7zM6 14a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1z" />
    </svg>
  );
}