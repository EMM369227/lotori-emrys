import React from 'react';
import { BarChart3, Target, TrendingUp, Clock, Zap } from 'lucide-react';
import { StatsData } from '../types/lottery';

interface StatisticsProps {
  stats: StatsData;
  lotteryTypes: Record<string, any>;
}

export function Statistics({ stats, lotteryTypes }: StatisticsProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Total Tirages</p>
              <p className="text-3xl font-bold">{stats.totalDraws}</p>
            </div>
            <BarChart3 className="h-8 w-8 text-blue-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium">Précision IA</p>
              <p className="text-3xl font-bold">{stats.successRate}%</p>
            </div>
            <Target className="h-8 w-8 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium">Tendance</p>
              <p className="text-2xl font-bold capitalize">
                {stats.recentTrend === 'up' ? 'Hausse' : stats.recentTrend === 'down' ? 'Baisse' : 'Stable'}
              </p>
            </div>
            <TrendingUp className={`h-8 w-8 ${stats.recentTrend === 'up' ? 'text-purple-200' : 'text-purple-300'}`} />
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm font-medium">Plus Fréquents</p>
              <div className="flex space-x-1 mt-2">
                {stats.mostFrequent.slice(0, 3).map((num, index) => (
                  <div key={index} className="w-6 h-6 bg-white bg-opacity-20 rounded-full flex items-center justify-center text-xs font-bold">
                    {num}
                  </div>
                ))}
              </div>
            </div>
            <Zap className="h-8 w-8 text-orange-200" />
          </div>
        </div>
      </div>

      {/* Statistiques par type de loterie */}
      <div className="bg-white rounded-2xl shadow-xl p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2" />
          Statistiques par Type de Loterie
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(stats.byLotteryType).map(([type, data]) => {
            const typeInfo = lotteryTypes[type] || { displayName: type, color: 'from-gray-500 to-gray-600', icon: '🎲' };
            return (
              <div key={type} className={`bg-gradient-to-br ${typeInfo.color} rounded-xl p-4 text-white`}>
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-lg">{typeInfo.icon}</span>
                  <h4 className="font-semibold">{typeInfo.displayName}</h4>
                </div>
                <div className="space-y-1 text-sm">
                  <p>Tirages: <span className="font-bold">{data.count}</span></p>
                  <p>Dernier: <span className="font-bold">{data.lastDraw}</span></p>
                  <div className="flex space-x-1 mt-2">
                    {data.avgNumbers.slice(0, 3).map((num: number, index: number) => (
                      <div key={index} className="w-5 h-5 bg-white bg-opacity-20 rounded-full flex items-center justify-center text-xs font-bold">
                        {num}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}