import React from 'react';
import { LotteryType } from '../types/lottery';

interface LotteryTypeSelectorProps {
  lotteryTypes: Record<string, LotteryType>;
  selectedType: string;
  onTypeChange: (type: string) => void;
}

export function LotteryTypeSelector({ lotteryTypes, selectedType, onTypeChange }: LotteryTypeSelectorProps) {
  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 mb-8">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Types de Loterie</h3>
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => onTypeChange('all')}
          className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
            selectedType === 'all'
              ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Tous les tirages
        </button>
        
        {Object.entries(lotteryTypes).map(([key, type]) => (
          <button
            key={key}
            onClick={() => onTypeChange(key)}
            className={`px-4 py-2 rounded-full font-medium transition-all duration-300 flex items-center space-x-2 ${
              selectedType === key
                ? `bg-gradient-to-r ${type.color} text-white shadow-lg`
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span>{type.icon}</span>
            <span>{type.displayName}</span>
          </button>
        ))}
      </div>
    </div>
  );
}