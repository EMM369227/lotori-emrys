import React from 'react';
import { Sparkles, TrendingUp } from 'lucide-react';

interface HeaderProps {
  isConnected: boolean;
  lastUpdate: string;
}

export function Header({ isConnected, lastUpdate }: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-purple-900 to-indigo-900 text-white shadow-2xl">
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full shadow-lg">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-300 to-orange-400 bg-clip-text text-transparent">
                Lotori Emrys
              </h1>
              <p className="text-blue-200 text-lg">Prédictions Numérologiques Avancées</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center space-x-2 mb-2">
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`}></div>
              <span className="text-sm">
                {isConnected ? 'Connecté à Lonato Togo' : 'Déconnecté'}
              </span>
            </div>
            <p className="text-xs text-gray-300">
              Dernière mise à jour: {lastUpdate}
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}