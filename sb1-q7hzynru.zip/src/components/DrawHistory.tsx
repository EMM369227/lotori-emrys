import React from 'react';
import { Calendar, Trophy, ExternalLink } from 'lucide-react';
import { LotteryDraw } from '../types/lottery';

interface DrawHistoryProps {
  draws: LotteryDraw[];
  lotteryTypes: Record<string, any>;
}

export function DrawHistory({ draws, lotteryTypes }: DrawHistoryProps) {
  const getLotteryTypeInfo = (type: string) => {
    return lotteryTypes[type] || { displayName: type, color: 'from-gray-500 to-gray-600', icon: '🎲' };
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Calendar className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Derniers Tirages Lonato Togo</h2>
      </div>
      
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {draws.map((draw) => {
          const typeInfo = getLotteryTypeInfo(draw.type);
          return (
            <div 
              key={draw.id} 
              className={`p-4 rounded-xl border-2 transition-all duration-300 hover:shadow-lg ${
                draw.isWinning 
                  ? 'border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50' 
                  : 'border-gray-200 bg-gray-50 hover:border-blue-300'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {draw.isWinning && <Trophy className="h-5 w-5 text-yellow-600" />}
                  <div className={`px-3 py-1 rounded-full text-xs font-bold text-white bg-gradient-to-r ${typeInfo.color}`}>
                    {typeInfo.icon} {typeInfo.displayName}
                  </div>
                  <span className="text-sm font-medium text-gray-600">
                    Tirage #{draw.drawNumber}
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500">{draw.date}</span>
                  <a 
                    href={draw.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:text-blue-700 transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </div>
              
              <div className="flex space-x-2 justify-center">
                {draw.numbers.map((number, index) => (
                  <div
                    key={index}
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md ${
                      draw.isWinning 
                        ? 'bg-gradient-to-br from-yellow-400 to-orange-500' 
                        : `bg-gradient-to-br ${typeInfo.color}`
                    }`}
                  >
                    {number}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-700 text-center">
          <strong>Connexion automatique</strong> - Les tirages sont récupérés automatiquement depuis lonato-togo.com toutes les 3 minutes
        </p>
      </div>
    </div>
  );
}