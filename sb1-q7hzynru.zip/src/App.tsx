import React from 'react';
import { Header } from './components/Header';
import { LotteryTypeSelector } from './components/LotteryTypeSelector';
import { DrawHistory } from './components/DrawHistory';
import { NutramerologicalAnalysis } from './components/NutramerologicalAnalysis';
import { Statistics } from './components/Statistics';
import { useLotteryData } from './hooks/useLotteryData';

function App() {
  const { 
    draws, 
    analysis, 
    stats, 
    isConnected, 
    isCalculating, 
    lastUpdate,
    selectedLotteryType,
    setSelectedLotteryType,
    lotteryTypes
  } = useLotteryData();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Header isConnected={isConnected} lastUpdate={lastUpdate} />
      
      <main className="container mx-auto px-6 py-8">
        {stats && <Statistics stats={stats} lotteryTypes={lotteryTypes} />}
        
        <LotteryTypeSelector 
          lotteryTypes={lotteryTypes}
          selectedType={selectedLotteryType}
          onTypeChange={setSelectedLotteryType}
        />
        
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
          <DrawHistory draws={draws} lotteryTypes={lotteryTypes} />
          
          {analysis && (
            <NutramerologicalAnalysis 
              analysis={analysis} 
              isCalculating={isCalculating} 
            />
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">À Propos de Lotori Emrys</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🔗</span>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Connexion Automatique</h3>
              <p className="text-gray-600 text-sm">Récupération automatique des tirages depuis lonato-togo.com toutes les 3 minutes.</p>
            </div>
            
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🧮</span>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Analyse Multi-Loteries</h3>
              <p className="text-gray-600 text-sm">Support complet des 6 types de loteries: Kadoo, Matinal, Super, Million, Prestige, Benz.</p>
            </div>
            
            <div className="text-center p-4">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Prédictions Instantanées</h3>
              <p className="text-gray-600 text-sm">Calculs numérologiques avancés et prédictions automatiques après chaque nouveau tirage.</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-6 mt-12">
        <div className="container mx-auto px-6 text-center">
          <p className="text-gray-300">© 2025 Lotori Emrys - Prédictions Numérologiques. Tous droits réservés.</p>
          <p className="text-gray-400 text-sm mt-2">
            Données récupérées automatiquement depuis lonato-togo.com - Les prédictions sont basées sur des calculs numérologiques.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;