import { LotteryDraw, LotteryType } from '../types/lottery';

export class LonatoScraper {
  private baseUrl = 'https://lonato-togo.com';
  private corsProxy = 'https://api.allorigins.win/raw?url=';
  
  private lotteryTypes: Record<string, LotteryType> = {
    kadoo: { name: 'kadoo', displayName: 'Loto Kadoo', color: 'from-blue-500 to-blue-600', icon: '🎯' },
    matinal: { name: 'matinal', displayName: 'Loto Matinal', color: 'from-yellow-500 to-orange-500', icon: '🌅' },
    super: { name: 'super', displayName: 'Loto Super', color: 'from-red-500 to-red-600', icon: '⚡' },
    million: { name: 'million', displayName: 'Loto Million', color: 'from-green-500 to-green-600', icon: '💰' },
    prestige: { name: 'prestige', displayName: 'Loto Prestige', color: 'from-purple-500 to-purple-600', icon: '👑' },
    benz: { name: 'benz', displayName: 'Loto Benz', color: 'from-gray-700 to-gray-800', icon: '🚗' }
  };

  async fetchLatestDraws(): Promise<LotteryDraw[]> {
    try {
      // En mode développement, on simule les données basées sur la structure réelle
      return this.generateRealisticDraws();
    } catch (error) {
      console.error('Erreur lors de la récupération des tirages:', error);
      return this.generateRealisticDraws();
    }
  }

  private generateRealisticDraws(): LotteryDraw[] {
    const draws: LotteryDraw[] = [];
    const types = Object.keys(this.lotteryTypes) as Array<keyof typeof this.lotteryTypes>;
    
    // Générer des tirages réalistes basés sur les vrais numéros de tirage observés
    const realisticDrawNumbers = {
      kadoo: 862,
      matinal: 311,
      super: 104,
      million: 104,
      prestige: 104,
      benz: 1797
    };

    types.forEach((type, index) => {
      for (let i = 0; i < 3; i++) {
        const drawNumber = realisticDrawNumbers[type] - i;
        const date = new Date(Date.now() - (index * 3 + i) * 24 * 60 * 60 * 1000);
        
        draws.push({
          id: Date.now() + index * 1000 + i,
          type,
          drawNumber,
          date: date.toLocaleDateString('fr-FR'),
          numbers: this.generateRealisticNumbers(type),
          url: `${this.baseUrl}/resultats-du-loto-${type}-tirage-${drawNumber}/`,
          isWinning: Math.random() > 0.85
        });
      }
    });

    return draws.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  private generateRealisticNumbers(type: string): number[] {
    // Générer des numéros réalistes selon le type de loto
    const ranges = {
      kadoo: { min: 1, max: 90, count: 5 },
      matinal: { min: 1, max: 90, count: 5 },
      super: { min: 1, max: 90, count: 5 },
      million: { min: 1, max: 90, count: 6 },
      prestige: { min: 1, max: 90, count: 5 },
      benz: { min: 1, max: 90, count: 5 }
    };

    const config = ranges[type as keyof typeof ranges] || ranges.kadoo;
    const numbers: number[] = [];
    
    while (numbers.length < config.count) {
      const num = Math.floor(Math.random() * config.max) + config.min;
      if (!numbers.includes(num)) {
        numbers.push(num);
      }
    }
    
    return numbers.sort((a, b) => a - b);
  }

  getLotteryTypes(): Record<string, LotteryType> {
    return this.lotteryTypes;
  }

  async fetchDrawDetails(url: string): Promise<number[] | null> {
    try {
      // Simulation de l'extraction des numéros depuis une page spécifique
      return this.generateRealisticNumbers('kadoo');
    } catch (error) {
      console.error('Erreur lors de la récupération des détails:', error);
      return null;
    }
  }
}