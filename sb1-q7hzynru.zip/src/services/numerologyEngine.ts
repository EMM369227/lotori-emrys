import { LotteryDraw, AnalysisResult } from '../types/lottery';

export class NumerologyEngine {
  private readonly MASTER_NUMBERS = [11, 22, 33];
  private readonly LUCKY_MULTIPLIERS = [3, 7, 9, 11, 13];

  analyzeDraws(draws: LotteryDraw[]): AnalysisResult {
    const allNumbers = draws.flatMap(draw => draw.numbers);
    const recentDraws = draws.slice(0, 5);
    
    return {
      dominantNumbers: this.findDominantNumbers(allNumbers),
      luckyNumbers: this.calculateLuckyNumbers(allNumbers),
      numerologySum: this.calculateNumerologySum(allNumbers),
      prediction: this.generatePrediction(draws),
      confidence: this.calculateConfidence(draws),
      patternAnalysis: this.analyzePatterns(recentDraws)
    };
  }

  private findDominantNumbers(numbers: number[]): number[] {
    const frequency = new Map<number, number>();
    
    numbers.forEach(num => {
      const reduced = this.reduceToSingleDigit(num);
      frequency.set(reduced, (frequency.get(reduced) || 0) + 1);
    });

    return Array.from(frequency.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([num]) => num);
  }

  private calculateLuckyNumbers(numbers: number[]): number[] {
    const numerologySum = this.calculateNumerologySum(numbers);
    const lucky: number[] = [];
    
    // Nombres basés sur la somme numérologique
    lucky.push(numerologySum);
    
    // Multiplication par les nombres sacrés
    this.LUCKY_MULTIPLIERS.forEach(multiplier => {
      const result = (numerologySum * multiplier) % 90 + 1;
      if (!lucky.includes(result)) {
        lucky.push(result);
      }
    });

    return lucky.slice(0, 5).sort((a, b) => a - b);
  }

  private calculateNumerologySum(numbers: number[]): number {
    const totalSum = numbers.reduce((sum, num) => sum + num, 0);
    return this.reduceToSingleDigit(totalSum);
  }

  private reduceToSingleDigit(num: number): number {
    while (num > 9 && !this.MASTER_NUMBERS.includes(num)) {
      num = num.toString().split('').reduce((sum, digit) => sum + parseInt(digit), 0);
    }
    return num;
  }

  private generatePrediction(draws: LotteryDraw[]): number[] {
    const recentNumbers = draws.slice(0, 3).flatMap(draw => draw.numbers);
    const allNumbers = draws.flatMap(draw => draw.numbers);
    const numerologySum = this.calculateNumerologySum(allNumbers);
    
    const prediction: number[] = [];
    
    // Prédiction basée sur les cycles numérologiques
    const cycleBase = numerologySum * 7;
    for (let i = 0; i < 5; i++) {
      const predicted = ((cycleBase + i * 13) % 90) + 1;
      if (!prediction.includes(predicted)) {
        prediction.push(predicted);
      }
    }

    // Ajustement basé sur les tendances récentes
    const recentAvg = recentNumbers.reduce((a, b) => a + b, 0) / recentNumbers.length;
    const adjustment = Math.floor(recentAvg / 10);
    
    return prediction.map(num => {
      const adjusted = num + adjustment;
      return Math.max(1, Math.min(90, adjusted));
    }).sort((a, b) => a - b);
  }

  private calculateConfidence(draws: LotteryDraw[]): number {
    if (draws.length < 5) return 60;
    
    const recentDraws = draws.slice(0, 5);
    const patterns = this.analyzePatterns(recentDraws);
    
    // Confiance basée sur la cohérence des patterns
    let confidence = 70;
    
    // Bonus pour les ratios équilibrés
    if (patterns.evenOddRatio >= 0.4 && patterns.evenOddRatio <= 0.6) confidence += 10;
    if (patterns.highLowRatio >= 0.4 && patterns.highLowRatio <= 0.6) confidence += 10;
    
    // Bonus pour les nombres consécutifs modérés
    if (patterns.consecutiveNumbers >= 1 && patterns.consecutiveNumbers <= 3) confidence += 5;
    
    return Math.min(95, confidence);
  }

  private analyzePatterns(draws: LotteryDraw[]): {
    evenOddRatio: number;
    highLowRatio: number;
    consecutiveNumbers: number;
  } {
    const allNumbers = draws.flatMap(draw => draw.numbers);
    
    const evenCount = allNumbers.filter(num => num % 2 === 0).length;
    const highCount = allNumbers.filter(num => num > 45).length;
    
    let consecutiveCount = 0;
    const sortedNumbers = [...new Set(allNumbers)].sort((a, b) => a - b);
    
    for (let i = 0; i < sortedNumbers.length - 1; i++) {
      if (sortedNumbers[i + 1] - sortedNumbers[i] === 1) {
        consecutiveCount++;
      }
    }

    return {
      evenOddRatio: evenCount / allNumbers.length,
      highLowRatio: highCount / allNumbers.length,
      consecutiveNumbers: consecutiveCount
    };
  }
}