
from flask import Flask, jsonify
from datetime import datetime
import random
import requests
from bs4 import BeautifulSoup
import telegram
import os

app = Flask(__name__)

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

BASE_URL = "https://lonato-togo.com/loto/resultats/"
MATINALE_SEARCH_URL = "https://lonato-togo.com/?s=matinal"

def get_real_last_10_results(tirage_type):
    url = f"{BASE_URL}{tirage_type}/"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        result_blocks = soup.select(".tie-block-container ul li")[:10]
        tirages = []
        for block in result_blocks:
            text = block.get_text()
            numbers = [int(n) for n in text.split() if n.isdigit()]
            if numbers:
                tirages.append(numbers[:5])
        return tirages if len(tirages) == 10 else mock_last_10_results(tirage_type)
    except:
        return mock_last_10_results(tirage_type)

def mock_last_10_results(tirage_type):
    return [sorted(random.sample(range(1, 50), 5)) for _ in range(10)]

def tirage_mystique():
    base_numbers = random.sample(range(1, 50), 10)
    filtered = [n for n in base_numbers if n % 9 == 0 or n % 9 == 1]
    return sorted(filtered[:5])

def edem369_ai_predict(tirage_type):
    tirages = get_real_last_10_results(tirage_type)
    flat = [num for tirage in tirages for num in tirage]
    freq = {}
    for num in flat:
        freq[num] = freq.get(num, 0) + 1
    top = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:3]
    prediction = [x[0] for x in top]
    return {
        "type": tirage_type,
        "date": datetime.utcnow().strftime("%Y-%m-%d"),
        "predicted_numbers": prediction,
        "confidence": random.randint(75, 95),
        "source": "IA Edem369 (analyse de séquence réelle)"
    }

def send_daily_predictions_to_telegram(predictions):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("⚠️ Token ou chat_id Telegram manquant")
        return
    bot = telegram.Bot(token=TELEGRAM_TOKEN)
    message = "\U0001F4AC *Prédictions Edem369 du jour :*\n"
    for p in predictions:
        message += f"\n*{p['type'].capitalize()}* → {', '.join(map(str, p['predicted_numbers']))} ({p['confidence']}%)"
    bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)

@app.route("/predict", methods=["GET"])
def predict_all():
    types = [
        "diamant", "gold", "cash", "boom", "benz", "prestige",
        "million", "super", "kadoo", "king", "sam", "bingo"
    ]
    predictions = [edem369_ai_predict(t) for t in types]
    send_daily_predictions_to_telegram(predictions)
    return jsonify({
        "tirage_mystique": tirage_mystique(),
        "edem369_predictions": predictions
    })

@app.route("/prediction-matinale-par-jour", methods=["GET"])
def prediction_matinale_par_jour():
    try:
        response = requests.get(MATINALE_SEARCH_URL)
        soup = BeautifulSoup(response.text, "html.parser")
        title = soup.select_one("h2.page-title span")
        result_blocks = soup.select(".tie-block-container ul li")

        for block in result_blocks:
            text = block.get_text()
            numbers = [int(n) for n in text.split() if n.isdigit()]
            if numbers:
                prediction = numbers[:5]
                return jsonify({
                    "titre": title.text if title else "Matinal",
                    "dernier_tirage_matinal": prediction,
                    "source": "Dernier tirage affiché dans les résultats de recherche 'matinal'"
                })

        return jsonify({"error": "Aucun tirage matinal trouvé."})

    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/donnees", methods=["GET"])
def toutes_les_donnees():
    types = [
        "diamant", "gold", "cash", "boom", "benz", "prestige",
        "million", "super", "kadoo", "king", "sam", "bingo"
    ]
    predictions = [edem369_ai_predict(t) for t in types]
    return jsonify({
        "date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "tirage_mystique": tirage_mystique(),
        "edem369_predictions": predictions,
        "tirage_matinal": prediction_matinale_par_jour().json
    })

if __name__ == '__main__':
    app.run(debug=True)
